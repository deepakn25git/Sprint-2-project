import cv2
import numpy as np

def run_dnn_webcam(prototxt_path="deploy.prototxt", model_path="res10_300x300_ssd_iter_140000.caffemodel", conf_threshold=0.5):
    """
    Deep Learning (CNN - ResNet-10 SSD) Face Detection using OpenCV DNN.
    Note: Requires 'deploy.prototxt' and 'res10_300x300_ssd_iter_140000.caffemodel' in the working directory.
    """
    try:
        net = cv2.dnn.readNetFromCaffe(prototxt_path, model_path)
    except Exception as e:
        print("Model files not found! Please download 'deploy.prototxt' and 'res10_300x300_ssd_iter_140000.caffemodel'.")
        print(f"Details: {e}")
        return

    cap = cv2.VideoCapture(0)
    print("Press 'q' to quit.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        (h, w) = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 1.0, (300, 300), (104.0, 177.0, 123.0))

        net.setInput(blob)
        detections = net.forward()

        for i in range(0, detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > conf_threshold:
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (startX, startY, endX, endY) = box.astype("int")

                text = f"Face: {confidence * 100:.1f}%"
                y = startY - 10 if startY - 10 > 10 else startY + 10
                cv2.rectangle(frame, (startX, startY), (endX, endY), (255, 140, 0), 2)
                cv2.putText(frame, text, (startX, y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 140, 0), 2)

        cv2.imshow("CNN / DNN Real-Time Face Detection", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_dnn_webcam()
