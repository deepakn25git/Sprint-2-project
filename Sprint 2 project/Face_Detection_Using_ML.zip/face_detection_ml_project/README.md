# Face Detection Using Machine Learning

A complete, ready-to-run Python project demonstrating real-time and static image face detection using OpenCV, Haar Cascades, and Deep Learning (DNN / Caffe SSD).

## System Workflow
1. **Image Capture:** Capture live video frames from a webcam or load a static image.
2. **Face Detection:** Use ML models (Haar Cascade or Deep Neural Network) to locate human faces.
3. **Face Recognition (Optional):** Extract facial embeddings to verify identity against known faces.
4. **Output:** Draw bounding boxes and confidence scores around detected faces.

## Technologies Required
- **Python 3.8+**
- **OpenCV (`opencv-python`)**: Image processing and computer vision pipelines.
- **NumPy**: Numerical operations and array manipulation.
- **Haar Cascade / CNN**: Face detection algorithms.
- **Webcam**: Real-time video input.

## Setup & Installation
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run Haar Cascade real-time face detection:
   ```bash
   python haar_face_detection.py
   ```
3. Run Image-based face detection:
   ```bash
   python image_face_detection.py --image sample.jpg
   ```
