# Face Detection Using Machine Learning - Overview

## 1. How Does Face Detection Work?
The system follows a four-stage pipeline:
1. **Image Capture:** Capture a live video frame via webcam or load a digital photograph.
2. **Face Detection:** Machine learning algorithms scan the image for facial patterns and landmarks to locate human faces.
3. **Face Recognition (Optional):** Compare detected facial features against a database to identify whether the face belongs to a known individual.
4. **Output:** Render bounding boxes (rectangles) and labels around each detected face.

## 2. Technologies Required
| Technology | Purpose |
| :--- | :--- |
| **Python** | Core programming language |
| **OpenCV** | Image processing & computer vision |
| **NumPy** | Matrix and numerical operations |
| **Haar Cascade / CNN** | Face detection models |
| **Webcam** | Real-time video input |

## 3. Different Approaches
1. **Haar Cascade:** Beginner-friendly, lightweight, and CPU-efficient; ideal for basic frontal face detection.
2. **CNN (Deep Learning):** Uses convolutional neural networks (e.g., ResNet SSD, MTCNN) to detect faces accurately across varied angles, lighting, and occlusions.
3. **YOLO (You Only Look Once):** Single-stage object detector optimized for ultra-fast, real-time multi-face detection.
