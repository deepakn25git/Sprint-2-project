import cv2
import argparse
import os

def detect_faces_in_image(image_path, output_path="output_detected.jpg"):
    if not os.path.exists(image_path):
        print(f"Error: Image '{image_path}' not found.")
        return

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    # Read image
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Detect faces
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    print(f"Found {len(faces)} face(s) in {image_path}.")

    # Draw rectangles
    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

    cv2.imwrite(output_path, img)
    print(f"Saved result to {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Detect faces in a static image.")
    parser.add_argument("--image", type=str, required=True, help="Path to input image")
    parser.add_argument("--output", type=str, default="output_detected.jpg", help="Path to output image")
    args = parser.parse_args()

    detect_faces_in_image(args.image, args.output)
